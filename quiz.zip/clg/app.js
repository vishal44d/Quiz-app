const express=require('express');
const path=require('path');
const mongoose=require('mongoose');
const bodyParser=require('body-parser');
const session =require('express-session');
const expressValidator=require('express-validator');
const fileUpload=require('express-fileupload');
const passport=require('passport');
const cookieParser = require('cookie-parser')

const app=express();
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({extended:true}));
app.use(express.static("public"));

// const reqfilter = (req, res, next)=>{
//   if(!req.query.age){
//     res.send("please provide age");
//   }else if (req.query.age<18) {
//       res.send("You are small");
//   }else{
//     next();
//   }
// }
//
// app.use(reqfilter);
var userRoute=require('./routes/userRoute');
app.use("/",userRoute);

var adminRoute=require('./routes/adminRoute');
app.use("/admin",adminRoute);

app.listen(3000, function(){
  console.log("Server is running on port 3000");
});