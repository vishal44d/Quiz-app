const express = require("express");
const admin_route = express();
const adminController = require("../controller/adminController");
 const loginController = require("../controller/loginController");
const session = require("express-session");
const config = require("../config/config");
const bodyParser = require("body-parser");
admin_route.use(bodyParser.json());
admin_route.use(bodyParser.urlencoded({extended:true}));
admin_route.use(express.static("public"));

admin_route.set('view engine', 'ejs');
admin_route.get("/home", adminController.loadhome);
admin_route.get("/loadaddQuestion", adminController.loadaddQuestion);
admin_route.post("/addQuestion",adminController.addQuestion);
admin_route.get("/getUsers", adminController.getUsers);


module.exports = admin_route;
