const express = require("express");
const user_route = express();
const userController = require("../controller/userController");
const loginController = require("../controller/loginController");
const session = require("express-session");
const config = require("../config/config");
//admin_route.use(session({secret:config.sessionSecret}));
const bodyParser = require("body-parser");
user_route.use(bodyParser.json());
user_route.use(bodyParser.urlencoded({extended:true}));
user_route.use(express.static("public"));
user_route.set('view engine', 'ejs');

user_route.get('/',loginController.login);
user_route.post("/login", loginController.verify);
user_route.get('/register', loginController.register);
user_route.post('/register', loginController.addUser);

user_route.get("/getDetails/:id", userController.getDataById );
user_route.post("/update/:id", userController.updateById);


user_route.get('/logout',loginController.login);



module.exports = user_route;
