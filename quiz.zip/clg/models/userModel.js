const mongoose = require("mongoose");
const Schema = mongoose.Schema;
mongoose.set('strictQuery', false);
mongoose.connect("mongodb://127.0.0.1/projectDB", {useNewUrlParser:true});

const userSchema = ({
  _id : {
    type : Schema.Types.ObjectID,
    required : true,
    auto : true
  },
  name : {
    type : String,
    required : true,
    trim : true
  },
  email : {
    type : String,
    required : true,
    trim : true
  },
  username : {
    type : String,
    required : true,
    trim : true,
    unique : true
  },
  phone : {
    type : String,
    required : true,
    trim : true
  },
  password : {
    type : String,
    required : true,
  },
  isAdmin : {
    type : Boolean,
    default : false
  }
});

const User = new mongoose.model("User", userSchema);
module.exports = User;
