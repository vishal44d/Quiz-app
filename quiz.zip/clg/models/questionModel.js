const mongoose = require("mongoose");
const Schema = mongoose.Schema;
mongoose.set('strictQuery', false);
mongoose.connect("mongodb://127.0.0.1/projectDB", {useNewUrlParser:true});

const questionSchema = ({
  _id : {
    type : Schema.Types.ObjectID,
    required : true,
    auto : true
  },
  title:{
    type: String,
    required : true,
    trim : true
  },
  option1 : {
    type : String,
    required : true,
    trim : true
  },
option2 : {
  type : String,
  required : true,
  trim : true
},
option3 : {
  type : String,
  required : true,
  trim : true
},
option4 : {
  type : String,
  required : true,
  trim : true
},
answer:{
  type: String,
  required : true,
  trim : true
}
});

const Question = new mongoose.model("Question", questionSchema);
module.exports = Question;
