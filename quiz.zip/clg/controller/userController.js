const User = require("../models/userModel");
const getDataById = async(req, res)=>{
  try{
    console.log(req.params);
    const result = await User.findOne({_id: req.params.id});
    if(result){
      res.send(result);
    }else{
      console.log("error");
    }
  }catch(error){
    console.log(error.message);
  }
}

const updateById = async(req, res)=>{
  try{
    console.log(req.body);
    const {name, username, email, phone} = req.body;
    const result = await User.updateOne(
      {_id: req.params.id},
      {$set:{name:name, username:username, email:email, phone:phone}}
    );
    if(result){
    var output = {
      success : true
    };
    res.send(output);
  }else{
    var output = {
      success : false
    };
    res.send(output);
  }
  }catch(error){
    console.log(error.message);
  }
}

module.exports = {getDataById, updateById}
