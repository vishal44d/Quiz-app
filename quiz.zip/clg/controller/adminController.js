const Question = require("../models/questionModel");
const User = require("../models/userModel");
const loadaddQuestion = async(req,res)=>{
  try{
      res.render("./admin/question");
  }catch(error){
    console.log(error.message);
  }
}

const loadhome = async(req, res)=>{
  try{
    Promise.all([
      Question.find().count(),
      User.find({isAdmin:{$ne: true}}).count(),
      User.find({isAdmin:true}).count()
    ]).then(([question,users,admins])=>{
      console.log(users);
      res.render("./admin/home",{question: question, users:users, admins: admins});
    }).catch(err=>{
      console.log(err);
    })

  }catch(error){
    console.log(error.message);
  }
}

const addQuestion = async(req,res)=>{
  try{
      console.log(req.body);
      const {question, option1, option2, option3, option4, answer} = req.body;
      if(question === "" || option1 === "" || option2 === "" || option3 === "" || option4 === "" || answer === ""){
        res.write("<script language='javascript'>alert('Please fill all the details');window.location='/admin/loadaddQuestion';</script>");
      }else{
        const newQuestion = new Question({
          title : question,
          option1 : option1,
          option2 : option2,
          option3 : option3,
          option4 : option4,
          answer : answer
        });
        newQuestion.save().then(()=>{
          res.write("<script language='javascript'>alert('Question added successfully');window.location='/admin/loadaddQuestion';</script>");
        }).catch(err=>{
          console.log(err);
        })
      }
  }catch(error){
    console.log(error.message);
  }
}

const getUsers = async(req,res)=>{
  try{
    const users = await User.find({isAdmin:{$ne:true}});
    if(users){
      res.render("./admin/userdata", {users:users});
    }
  }catch(error){
    console.log(error.message);
  }
}

module.exports= {loadaddQuestion, loadhome, addQuestion, getUsers}
