const User = require("../models/userModel");
const md5 = require("md5");
const _ = require("lodash");
const login = async(req,res)=>{
    try{
        res.render("login");
    }catch(error){
        console.log(error.message);
    }
}

const register = async(req,res)=>{
    try{
        res.render("register");
    }catch(error){
        console.log(error.message);
    }
}

const verify = async(req, res)=>{
  try{
    const {loginid, password} = req.body;
    const result = await User.findOne({username:loginid});
    if(result){

      if(result.password === md5(password)){
        if(result.isAdmin === true){
          res.redirect("admin/home");
        }else{
          res.render("users/home", {user: result});
        }
      }else{
        res.write("<script language='javascript'>alert('Invalid login Details');window.location='/';</script>");
      }
    }else{
      res.write("<script language='javascript'>alert('Invalid login Details');window.location='/';</script>");
    }
  }catch(error){
    console.log(error.message);
  }
}

const addUser = async(req,res)=>{
  try{
    const {name, email, username, phone, password} = req.body;
    const user = new User({
      name : _.capitalize(name.trim()),
      email : email,
      username : username,
      phone : phone,
      password : md5(password)
    });
    user.save().then((response)=>{
      res.render("users/home", {user: response})
    }).catch(err=>{
        res.write("<script language='javascript'>alert('Username already exist');window.location='/register';</script>");
    })
  }catch(error){
    console.log(error.message);
  }
}
module.exports = { login, register, verify,addUser}
